﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrainTicketMachine_Entites
{
    public class searchstationResultSet
    {
        public List<string> stations { get; set; }
        public List<char> allNextCharacters { get; set; }
        public searchstationResultSet(List<searchstation> searchResults)
        {
            stations = new List<string>();
            allNextCharacters = new List<char>();

            foreach (searchstation s in searchResults)
            {
                stations.Add(s.station);
                allNextCharacters.Add(s.nextCharacter);
            }

            allNextCharacters.Remove(allNextCharacters.Where(c => c == (char)0).FirstOrDefault());
        }
    }
}

