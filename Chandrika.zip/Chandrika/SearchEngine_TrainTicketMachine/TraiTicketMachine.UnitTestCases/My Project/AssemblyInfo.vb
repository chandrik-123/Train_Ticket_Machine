﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("TraiTicketMachine.UnitTestCases")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("HP Inc.")>
<Assembly: AssemblyProduct("TraiTicketMachine.UnitTestCases")>
<Assembly: AssemblyCopyright("Copyright © HP Inc. 2020")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

<Assembly: Guid("6e6d04f1-31e1-4b73-9d82-671de7154592")>

' <Assembly: AssemblyVersion("1.0.*")> 
<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
