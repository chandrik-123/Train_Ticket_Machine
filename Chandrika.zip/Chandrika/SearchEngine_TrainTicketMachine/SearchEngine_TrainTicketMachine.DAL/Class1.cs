﻿using System;

namespace SearchEngine_TrainTicketMachine.DAL
{
    public class Class1
    {
    }
}
