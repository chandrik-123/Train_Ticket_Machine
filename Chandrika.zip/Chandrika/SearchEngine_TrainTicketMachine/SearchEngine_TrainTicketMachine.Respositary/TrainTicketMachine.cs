﻿using SearchEngine_TrainTicketMachine.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TrainTicketMachine_Entites;

namespace SearchEngine_TrainTicketMachine.Respositary
{
    public class TrainTicketMachine : ITrainTicketMachine
    {
        public List<searchstation> GetAllStartedWithName(string input)
        {
            try
            {
                string[] arraystations = GetAllStations();

                List<searchstation> searchResultList = new List<searchstation>();
                for (int i = 0; i < StationsArray.stations.Length; i++)
                {
                    if (arraystations[i].StartsWith(input))
                    {
                        searchResultList.Add(new searchstation
                        {
                            station = arraystations[i],
                            nextCharacter = GetNextCharacter(arraystations[i], input)
                        });
                    }
                }

                return searchResultList;
            }

            catch
            {
                return Enumerable.Empty<searchstation>().ToList();
            }
        }

        public string[] GetAllStations()
        {
            return StationsArray.stations;
        }

        public char GetNextCharacter(string reference, string input)
        {
            try
            {
                return reference.Replace(input, String.Empty).ToCharArray().ToList()[0];
            }

            catch
            {
                return (char)0;
            }
        }
    }
}
